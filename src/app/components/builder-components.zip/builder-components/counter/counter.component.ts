import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-counter',
  templateUrl: './counter.component.html',
  styleUrls: ['./counter.component.scss'],
})
export class CounterComponent implements OnInit {
@Input() row;
  constructor() { }

  ngOnInit() {
     this.run_count()
   
  }
   

  run_count(){
  var counters= setInterval(runTimer,10)
  var initial_count = 1
   function runTimer(){
     var allCounters = document.querySelectorAll('.count_value')
     console.log(allCounters);
     clearInterval(counters)
   }
  }
}
