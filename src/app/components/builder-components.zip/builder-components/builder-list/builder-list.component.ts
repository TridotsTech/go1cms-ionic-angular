import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-builder-list',
  templateUrl: './builder-list.component.html',
  styleUrls: ['./builder-list.component.scss','../test/test.component.scss'],
})
export class BuilderListComponent implements OnInit {
  // @Input() row;
  constructor() { }

  ngOnInit() {}

}
