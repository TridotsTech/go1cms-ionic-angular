import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-testimonial',
  templateUrl: './testimonial.component.html',
  styleUrls: ['./testimonial.component.scss','../test/test.component.scss'],
})
export class TestimonialComponent implements OnInit {
@Input() row;
  constructor() { }

  ngOnInit() {}

}
