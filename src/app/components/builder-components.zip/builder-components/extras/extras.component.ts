import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-extras',
  templateUrl: './extras.component.html',
  styleUrls: ['./extras.component.scss','../test/test.component.scss'],
})
export class ExtrasComponent implements OnInit {
@Input() row;
  constructor() { }
  
  ngOnInit() {}

}
