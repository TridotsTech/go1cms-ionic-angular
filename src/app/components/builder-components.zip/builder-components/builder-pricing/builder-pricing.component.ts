import { Component, OnInit,Input } from '@angular/core';

@Component({
  selector: 'app-builder-pricing',
  templateUrl: './builder-pricing.component.html',
  styleUrls: ['./builder-pricing.component.scss','../test/test.component.scss'],
})
export class BuilderPricingComponent implements OnInit {
  @Input() row;
  constructor() { }

  ngOnInit() {}

}
