import { Component, OnInit } from '@angular/core';

interface ngStyleObj {
  'grid-template-columns'?:string
}

@Component({
  selector: 'app-template-builder',
  templateUrl: './template-builder.component.html',
  styleUrls: ['./template-builder.component.scss','../test/test.component.scss'],
})
export class TemplateBuilderComponent implements OnInit {

  constructor() { }
  ngOnInit() {}
  grid_columns:ngStyleObj

  sections = [
    {
      columns : [
        {
          width:"33%",
          components:[
            {type:'Card Style1',title:'Realtime Collaboration',image:'https://cdn.pixabay.com/photo/2016/03/09/09/30/woman-1245817__480.jpg',
            content:"Lorem Ipsum is simply dummy text of the printing and typesetting industry.",button_name:'button'},
      ]
        },
        {
          width:"33%",
          components:[
            {type:'Card Style2',title:'Realtime Collaboration',image:'https://cdn.pixabay.com/photo/2016/03/09/09/30/woman-1245817__480.jpg',
            content:"Lorem Ipsum is simply dummy text of the printing and typesetting industry.",button_name:'button'},
      ]
        },
        {
          width:"33%",
          components:[
            {type:'Card Style3',title:'Realtime Collaboration',image:'https://cdn.pixabay.com/photo/2016/03/09/09/30/woman-1245817__480.jpg',
            content:"Lorem Ipsum is simply dummy text of the printing and typesetting industry.",button_name:'button'},
      ]
        },
      ]
    },
  ]
        assign(data){
          let new_columns = ''
         data.columns.map(c=>{
             new_columns += new_columns.length==0 ? `${c.width}` : ` ${c.width}`
          })
          this.grid_columns = {
            'grid-template-columns':new_columns
          }
          return this.grid_columns
       }
}
