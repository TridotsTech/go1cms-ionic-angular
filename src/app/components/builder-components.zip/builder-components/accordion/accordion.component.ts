import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-accordion',
  templateUrl: './accordion.component.html',
  styleUrls: ['./accordion.component.scss','../test/test.component.scss'],
})
export class AccordionComponent implements OnInit {
   @Input() row;
  constructor() { }

  ngOnInit() {
   
  }
  open_close(count,data){
    console.log(data);
    data.map((res,i)=>{
      console.log(i,count);
      if(i==count){
        res.show = res.show ? false : true;
      }else{
        res.show = false;
      }
    })
  }
  checking(value,index){
    value.map((res,i)=>{
      if(i == index){
        res.show = !res.show;
      }else{
        res.show = false;
      }
    })
 } 
}
