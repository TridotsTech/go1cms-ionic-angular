import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-blurb',
  templateUrl: './blurb.component.html',
  styleUrls: ['./blurb.component.scss','../test/test.component.scss'],
})
export class BlurbComponent implements OnInit {
  @Input() row;
  constructor() { }

  ngOnInit() {}

}
