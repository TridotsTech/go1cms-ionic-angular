import { ViewportScroller } from '@angular/common';
import {
  Component,
  ElementRef,
  EventEmitter,
  HostListener,
  Input,
  OnInit,
  Output,
  Renderer2,
} from '@angular/core';
import { Router } from '@angular/router';

import { DbService } from 'src/app/services/db.service';

import {
  AlertController,
  MenuController,
  ModalController,
  NavController,
  Platform,
} from '@ionic/angular';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss'],
})
export class HeaderComponent implements OnInit {
  @Input() back_route;
  @Input() home;
  @Input() no_search_icon;
  @Input() no_home;
  @Input() no_cart;
  // @Input() cat_products;
  @Input() title;
  @Input() search_btn;
  @Input() menu_btn;
  @Input() menu;
  @Input() desktop;
  @Output() cart_pop = new EventEmitter();

  search_area = false;

  scroll_icon = false

  constructor(private menuCtrl: MenuController, private navCtrl: NavController, private platform: Platform, public db: DbService,private alertCtrl:AlertController,private router:Router,private modalCtrl:ModalController,private eRef:ElementRef,private renderer2: Renderer2,private scroller: ViewportScroller) {

   }

  ngOnInit() {
    this.db.ismobile = this.db.checkmobile();
    
  }

  close_menu() {
    this.menuCtrl.close();
  }





  
  @HostListener('window:resize', ['$event'])
  private func(){
     this.db.ismobile = this.db.checkmobile();
  }


 
  menu_categories =[
    {
      text: 'About Us',
      route: '/about-us'
    },
    {
      text : 'Contact Us',
      route:'/contact-us'
    }
  ]


  


  }
  
